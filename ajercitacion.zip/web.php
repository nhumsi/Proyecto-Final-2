<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// Route::get('/suma/{numUno}+{numDos}', function ($uno, $dos) {
//     $suma = $uno + $dos;
//     return "La suma es : $suma";
// });

Route::get('/suma/{numUno}+{numDos}+{numTres?}', function ($uno, $dos, $tres=0) {
    $suma = $uno + $dos + $tres;
    return "La suma es : $suma";
});

Route::get('/peliculas', "PeliculaController@listado" );
Route::get('/pelipage/{page?}', "PeliculaController@paginado" );

// Route::get('/peliculas', function () {
//     $pelis = [
//         ['Peli uno', 3],
//         ['Peli dos', 5],
//         ['Peli tres', 4],
//         ['Peli cutro', 5],
//         ['Peli cinco', 43],
//     ];
//     $vars = compact('pelis');
//     return view('peliculas', $vars);
// });

Route::get('/pelicula/{id}', "PeliculaController@detalle");
// Route::get('/pelicula/{id}', function ( $id ) {

//     $pelis = [
//         ['Peli uno', 3],
//         ['Peli dos', 5],
//         ['Peli tres', 4],
//         ['Peli cuatro', 5],
//         ['Peli cinco', 43],
//     ];

//     $peli = $pelis[ $id ];
//     $vars = compact('peli');
//     return view('pelicula', $vars);
// });
Route::get('/actores/buscar', "ActorController@search");
Route::get('/pelicula/top', "PeliculaController@top");
Route::get('/actores', "ActorController@directory");
Route::get('/actor/{id}', "ActorController@show");

    